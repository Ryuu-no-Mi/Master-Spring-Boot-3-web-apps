package com.ryuu_nomi.curso.springboot.app.springboot_crud_jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCrudJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCrudJpaApplication.class, args);
	}

}
