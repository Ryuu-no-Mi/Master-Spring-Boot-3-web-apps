package com.ryuu_nomi.curso.springboot.app.springboot_crud_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
